<?php

$contact=mysqli_connect("Localhost", "root", "", "cook_db");
if( $contact->connect_error)
  {
    die ("Connection Failed".contact->connect_error);
  }

?>
